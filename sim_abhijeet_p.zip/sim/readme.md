This is a simple project strucure for simulation

-> To run the test cases run the test/simulation_test.py 
-> To run the main process run simulation/main.py


Author: Abhijeet P