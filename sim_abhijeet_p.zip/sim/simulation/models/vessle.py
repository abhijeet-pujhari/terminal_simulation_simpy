class Vessel:
    def __init__(self, name, containers):
        self.name = name
        self.containers = containers
